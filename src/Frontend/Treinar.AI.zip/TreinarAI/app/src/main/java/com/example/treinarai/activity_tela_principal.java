package com.example.treinarai;

import android.content.Intent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class activity_tela_principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);

        // Obtendo a referência para o WebView
        WebView webView = findViewById(R.id.webView2);

        // Limpa o cache do WebView
        webView.clearCache(true);

        // Configurando as configurações do WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Habilita a execução de JavaScript no WebView

        // Carrega o código HTML do Typebot no WebView
        String typebotHtml = "<html><head><title>Typebot</title></head><body><iframe src=\"https://typebot.co/lead-generation-scalex\" style=\"border: none; width: 350px; height: 427px\"></iframe></body></html>";
        webView.loadData(typebotHtml, "text/html", null);

        // Define um WebViewClient para garantir que os links internos sejam carregados no WebView
        webView.setWebViewClient(new WebViewClient());

        // Encontrando o ícone de texto no layout
        TextView tituloTreinarAI2 = findViewById(R.id.tituloTreinarAI3);

        // Definindo um listener de clique para o ícone de texto
        tituloTreinarAI2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar de volta para a tela de login (MainActivity)
                Intent intent = new Intent(activity_tela_principal.this, MainActivity.class);
                startActivity(intent);
                finish(); // Encerra a atividade atual para evitar acumulação na pilha de atividades
            }
        });

        // Verifica se há uma Intent associada a esta atividade
        Intent intent = getIntent();
        if (intent != null) {
            // Obtém o nome de usuário da Intent
            String username = intent.getStringExtra("USERNAME");
            // Verifica se o nome de usuário não é nulo ou vazio
            if (username != null && !username.isEmpty()) {
                // Encontra o TextView para exibir a mensagem de boas-vindas
                TextView mensagemBemVindo = findViewById(R.id.textView3);
                // Define o texto da mensagem de boas-vindas
                mensagemBemVindo.setText("Bem-vindo, " + username + "!");
            }
        }
    }
}
