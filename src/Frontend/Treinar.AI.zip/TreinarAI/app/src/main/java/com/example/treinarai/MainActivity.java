package com.example.treinarai;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText campoEmail;
    private EditText campoSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        campoEmail = findViewById(R.id.campoEmail);
        campoSenha = findViewById(R.id.campoSenha);
        campoSenha.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        Button botaoEntrar = findViewById(R.id.botaoEntrar);
        Button botaoCriarConta = findViewById(R.id.botaoCriarConta);
        Button botaoEsqueciSenha = findViewById(R.id.botaoEsqueciSenha);

        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarLogin();
            }
        });

        botaoCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TelaCadastro.class);
                startActivity(intent);
            }
        });

        botaoEsqueciSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RedefinirSenha.class);
                startActivity(intent);
            }
        });
    }

    private void validarLogin() {
        String email = campoEmail.getText().toString().trim();
        String senha = campoSenha.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(senha)) {
            Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else if (!isValidEmail(email)) {
            Toast.makeText(MainActivity.this, "Por favor, insira um email válido", Toast.LENGTH_SHORT).show();
        } else if (!isValidPassword(senha)) {
            Toast.makeText(MainActivity.this, "A senha deve conter pelo menos 8 caracteres, incluindo letras e números", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(MainActivity.this, activity_tela_principal.class);
            startActivity(intent);
        }
    }

    // Método para verificar se o email é válido usando expressão regular
    private boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    // Método para verificar se a senha atende aos critérios mínimos
    private boolean isValidPassword(String password) {
        // Padrão que verifica se a senha contém pelo menos 8 caracteres, incluindo letras e números
        return password != null && password.length() >= 8 && password.matches(".*[A-Za-z].*") && password.matches(".*\\d.*");
    }
}
